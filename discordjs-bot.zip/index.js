const Discord = require("discord.js");
const bot = new Discord.Client();
const cfg = require("./config.json");
const errors = require("./errors.json");

let ascii_text_generator = require('ascii-text-generator');

console.log("Ausgabe der Datei config.json:");
console.log("");
console.log(cfg);
console.log("");

bot.on("ready", () => {
	console.log("Der Bot ist nun bereit, um verwendet zu werden!");
});

bot.on("message", (message) => {

	if (message.content.startsWith(cfg.prefix)) {
		const args = message.content.slice(cfg.prefix.length).trim().split(/ +/);
		const cmd = args.shift().toLowerCase();

		 if (cmd == "kick") {
			message.delete();
			let kUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
			if (!kUser) return message.reply("Dieser User kann nicht gefunden werden!");
			let kReason = args.join(" ").slice(22);
			if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply(errors.permissions);
			if (kUser.hasPermission("MANAGE_MESSAGES")) return message.reply(errors.permissions);

			let kickEmbed = new Discord.RichEmbed()
				.setDescription("--- Kick ---")
				.setColor("#e56b00")
				.addField("Gekickt wurde", "${kUser} mit der ID ${kUser.id}")
				.addField("Gekickt von", "<@${message.author.id}> mit der ID ${message.author.id}")
				.addField("Gekickt im Kanal", message.channel)
				.addField("Gekickt um", message.createdAt)
				.addField("Grund", kReason);

			message.guild.member(kUser).kick(kReason);
			message.channel.send(kickEmbed);

			return;
		} else if (cmd == "ban" || cmd == "bann") {
			message.delete();
			let bUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
			if (!bUser) return message.channel.send("Dieser User kann nicht gefunden werden!");
			let bReason = args.join(" ").slice(22);
			if (!message.member.hasPermission("MANAGE_MEMBERS")) return message.channel.send(errors.permissions);
			if (bUser.hasPermission("MANAGE_MESSAGES")) return message.channel.send(errors.permissions);

			let banEmbed = new Discord.RichEmbed()
				.setDescription("--- Bann ---")
				.setColor("#bc0000")
				.addField("Gebannt wurde", "${bUser} mit der ID ${bUser.id}")
				.addField("Gebannt von", "<@${message.author.id}> mit der ID ${message.author.id}")
				.addField("Gebannt im Kanal", message.channel)
				.addField("Gebannt um", message.createdAt)
				.addField("Grund", bReason);

			message.guild.member(bUser).ban(bReason);
			message.channel.send(banEmbed);

			return;
		} else if (cmd == "serverinfo") {
			message.delete();
			if (message.guild) {
				let sicon = message.guild.iconURL;
				let serverembed = new Discord.RichEmbed()
					.setDescription("Serverinformationen (Seite 1/1)")
					.setColor("#15f153")
					.setThumbnail(sicon)
					.addField("Name des Servers", message.guild.name)
					.addField("Server erstellt", message.guild.createdAt)
					.addField("Server betreten", message.member.joinedAt)
					.addField("Anzahl an Mitgliedern", message.guild.memberCount);

				return message.channel.send(serverembed);
			} else {
				message.reply("Du kannst diesen Befehl nur auf einem Server ausführen!");
			}
		} else if (cmd == "help" || cmd == "botinfo") {
			message.delete();
			if(args.length == 1){
				if(args[0] == "1"){
					let bicon = bot.user.displayAvatarURL;
					let botembed = new Discord.RichEmbed()
					.setDescription("Botinformationen (Seite 1/3) | Statistiken")
					.setColor("#15f153")
					.setThumbnail(bicon)
					.addField("Name des Bots", bot.user.username)
					.addField("Bot erstellt", bot.user.createdAt);

					return message.channel.send(botembed);
				}else if(args[0] == "2"){
					let bicon = bot.user.displayAvatarURL;
					let botembed = new Discord.RichEmbed()
					.setDescription("Botinformationen (Seite 2/3) | Features (Events)")
					.setColor("#15f153")
					.setThumbnail(bicon)
					.addField("Protokollierung der Nachrichten (Server)", "Protokolliert alle Nachrichten, welche auf Servern gesendet wurden, und sendet diese in den angegeben Kanal")
					.addField("Protokollierung der Nachrichten (privat)", "Protokolliert alle Nachrichten, welche privat gesendet wurden, und sendet diese in den angegeben Kanal")
					.addField("Protokollierung des 'typingStart'-Events", "Protokolliert, zu welchem Zeitpunkt User angefangen haben, zu schreiben")
					.addField("Protokollierung des 'typingStop'-Events", "Protokolliert, zu welchem Zeitpunkt User aufgehört haben, zu schreiben")
					.addField("Protokollierung des 'guildUnavailable'-Events", "Protokolliert, zu welchem Zeitpunkt Server nicht erreichbar waren")
					.addField("Protokollierung des 'guildUpdate'-Events", "Protokolliert Änderungen an Servern")
					.addField("Protokollierung des 'messageDelete'-Events", "Protokolliert alle Nachrichten, welche auf Servern gesendet wurden, und sendet diese in den angegeben Kanal")
					.addField("Protokollierung des 'messageReactionAdd'-Events", "Protokolliert, wenn User eine Reaktion zu einer Nachricht hinzufügen")
					.addField("Protokollierung des 'messageReactionRemove'-Events", "Protokolliert, wenn User eine Reaktion von einer Nachricht entfernen")
					.addField("Protokollierung des 'guildBanAdd'-Events", "Protokolliert, welche User von Servern gebannt wurden")
					.addField("Protokollierung des 'guildBanRemove'-Events", "Protokolliert, welche User von Servern entbannt wurden")
					.addField("Protokollierung des 'guildUpdate'-Events", "Protokolliert Änderungen an Servern");

					return message.channel.send(botembed);
				}else if(args[0] == "3"){
					let bicon = bot.user.displayAvatarURL;
					let botembed = new Discord.RichEmbed()
					.setDescription("Botinformationen (Seite 3/3) | Features (Befehle)")
					.setColor("#15f153")
					.setThumbnail(bicon)
					.addField(cfg.prefix + "kick <User> <Grund>", "Kickt User vom aktuellen Server (ggf. mit Begründung)")
					.addField(cfg.prefix + "ban(n) <User> <Grund>", "Bannt User vom aktuellen Server (ggf. mit Begründung)")
					.addField(cfg.prefix + "serverinfo", "Gibt dir Informationen über den aktuellen Server")
					.addField(cfg.prefix + "ascii <ASCII-Art>", "Postet ein ASCII-Art in den Chat")
					.addField(cfg.prefix + "ascii custom <Custom ASCII-Art>", "Postet ein eigenes ASCII-Art in den Chat (Konvertierung von Text zu ASCII)")
					.addField(cfg.prefix + "ascii list", "Listet alle vordefinierten ASCII-Arts auf");

					return message.channel.send(botembed);
				}else{
					message.reply(errors.syntax);
				}
			}else{
				message.reply(errors.sonderfall);
			}
		} else if (cmd == "ascii") {
			message.delete();
			if (args.length > 0) {
				if (args[0] == "custom") {
					cascii = args[1];
					let text = "/*\n" + ascii_text_generator(cascii, "2") + "\n*/";
					message.channel.send(text);
				} else if (args[0] == "list") {
					message.reply("```Aktuell verfügbare ASCII-Arts:\n\n-> Bird / Vogel```");
				} else if (args[0] == "bird" || args[0] == "vogel") {
					var bird = require("fs");
					bird.readFile("./asciiarts/bird.txt", "utf8", function (err, data) {
						if (err) throw err;
						message.channel.send(data);
					});
				} else {
					message.reply(errors.syntax);
				}
			} else {
				message.reply(errors.syntax);
			}
		} else if (cmd == "bulkdelete") {
			message.delete();
			if (args.length == 1) {
				if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply(errors.permissions);
				message.channel.bulkDelete(args[0]);
			} else {
				message.reply(errors.syntax);
			}
		}
	}

	if (message.guild) {
		if (message.guild.name != "Logging Discord") {
			var channel = bot.channels.get("536940172827426816");

			console.log("Server: " + message.guild.name + "\nKanal: " + message.channel.name + "\nAuthor: " + message.author.tag + " \nUhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\nNachricht:\n" + message.content);

			channel.send("══════════════════════════════\nServer: " + message.guild.name + "\nKanal: " + message.channel.name + "\nAuthor: " + message.author.tag + " \nUhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\nNachricht:\n" + message.content + "\n══════════════════════════════");
		}
	} else if (message != message.guild) {
		var channel = bot.channels.get("536940647396016138");

		console.log("Author: " + message.author.tag + " \nUhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\nNachricht:\n" + message.content);

		channel.send("══════════════════════════════\nAuthor: " + message.author.tag + " \nUhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\nNachricht:\n" + message.content + "\n══════════════════════════════");
	}
});

bot.on("typingStart", (channel, user) => {
	var channel = bot.channels.get("536952622427406338");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat angefangen zu schreiben.");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat angefangen zu schreiben.");
});

bot.on("typingStop", (channel, user) => {
	var channel = bot.channels.get("536961186655240192");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat aufgehört zu schreiben.");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat aufgehört zu schreiben.");
});

bot.on("guildUnavailable", (guild) => {
	var channel = bot.channels.get("536988587497881635");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + guild.toString() + " ist aktuell nicht verfügbar!");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + guild.toString() + " ist aktuell nicht verfügbar!");
});

bot.on("guildUpdate", (oldGuild, newGuild) => {
	var channel = bot.channels.get("536991787101716481");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + oldGuild.toString() + " wurde aktualisiert!\n\nAktualisiert: " + newGuild.toString());

	channel.send("```Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + oldGuild.toString() + " wurde aktualisiert!\n\nAktualisiert: " + newGuild.toString() + "```");
});

bot.on("messageDelete", (message) => {
	var channel = bot.channels.get("536995930176487444");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\nEs wurde eine Nachricht gelöscht:\n\n" + message.toString());

	channel.send("```Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\nEs wurde eine Nachricht gelöscht:\n\n" + message.toString() + "```");
});

bot.on("messageReactionAdd", (messageReaction, user) => {
	var channel = bot.channels.get("536998053899534336");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat eine Reaktion zu einer Nachricht hinzugefügt.");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat eine Reaktion zu einer Nachricht hinzugefügt.");
});

bot.on("messageReactionRemove", (messageReaction, user) => {
	var channel = bot.channels.get("536998078608310315");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat eine Reaktion von einer Nachricht entfernt.");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " hat eine Reaktion von einer Nachricht entfernt.");
});

bot.on("guildBanAdd", (guild, user) => {
	var channel = bot.channels.get("537000153962250250");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " wurde vom Server " + guild.toString() + " gebannt.");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " wurde vom Server " + guild.toString() + " gebannt.");
});

bot.on("guildBanRemove", (guild, user) => {
	var channel = bot.channels.get("537000174031994880");

	console.log("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " wurde vom Server " + guild.toString() + " entbannt.");

	channel.send("Uhrzeit: " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds() + "\n\n" + user.toString() + " wurde vom Server " + guild.toString() + " entbannt.");
});

bot.login(cfg.token);